"use strict";
/* =========================================================
  TRIPTROVE
========================================================= */

const STORAGE_KEYS = {
  trips: "triptrove_trips_v1",
  expenses: "triptrove_expenses_v1"
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const money = amount =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2
  }).format(Number(amount) || 0);

const todayISO = () => {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
};

const uid = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function readStorage(key, fallback = []) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

let trips = readStorage(STORAGE_KEYS.trips);
let expenses = readStorage(STORAGE_KEYS.expenses);

function persistData() {
  try {
    localStorage.setItem(STORAGE_KEYS.trips, JSON.stringify(trips));
    localStorage.setItem(STORAGE_KEYS.expenses, JSON.stringify(expenses));
    return true;
  } catch (error) {
    console.error("Unable to save TripTrove data:", error);
    toast("Browser storage is unavailable or full. Export your data or free up space.", true);
    return false;
  }
}

function toast(message, isError = false) {
  const region = $("#toastRegion");
  const item = document.createElement("div");
  item.className = `toast${isError ? " error" : ""}`;

  const text = document.createElement("span");
  text.textContent = message;

  const close = document.createElement("button");
  close.type = "button";
  close.textContent = "×";
  close.setAttribute("aria-label", "Dismiss notification");
  close.addEventListener("click", () => item.remove());

  item.append(close, text);
  region.append(item);

  window.setTimeout(() => item.remove(), 4200);
}
/* ---------------- DESTINATIONS ---------------- */
const destinations = [
  {
    name: "Kyoto",
    country: "Japan",
    description: "Quiet bamboo paths, beautiful temples, and timeless traditions.",
    interest: "Culture",
    image: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=900&q=80"
  },
  {
    name: "Amalfi Coast",
    country: "Italy",
    description: "Sunlit villages, dramatic coastlines, and long lunches by the sea.",
    interest: "Relaxation",
    image: "https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=900&q=80"
  },
  {
    name: "Swiss Alps",
    country: "Switzerland",
    description: "Mountain trails, alpine lakes, and breathtaking landscapes.",
    interest: "Nature",
    image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=900&q=80"
  },
  {
    name: "Bali",
    country: "Indonesia",
    description: "Tropical landscapes, island culture, and peaceful retreats.",
    interest: "Relaxation",
    image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=900&q=80"
  },
  {
    name: "Marrakech",
    country: "Morocco",
    description: "Colorful markets, beautiful architecture, and vibrant local life.",
    interest: "Culture",
    image: "https://images.unsplash.com/photo-1489749798305-4fea3ae63d43?auto=format&fit=crop&w=900&q=80"
  },
  {
    name: "Iceland",
    country: "Iceland",
    description: "Volcanic landscapes, waterfalls, and extraordinary open spaces.",
    interest: "Adventure",
    image: "https://images.unsplash.com/photo-1476610182048-b716b8518aae?auto=format&fit=crop&w=900&q=80"
  }
];

function destinationCard(destination, index) {
  const name = escapeHTML(destination.name);
  const country = escapeHTML(destination.country);
  const description = escapeHTML(destination.description);
  const interest = escapeHTML(destination.interest);
  const image = escapeHTML(destination.image);

  return `
    <article class="destination-card">
      <div class="destination-photo">
        <img src="${image}" alt="${name}, ${country}" loading="lazy">
        <span class="destination-number">0${index + 1} / DISCOVER</span>
      </div>
      <div class="destination-body">
        <span class="destination-location">${country}</span>
        <h3>${name}</h3>
        <p>${description}</p>
        <div class="destination-bottom">
          <span class="destination-tag">${interest}</span>
          <button class="destination-action" type="button"
            data-plan-destination="${name}, ${country}"
            aria-label="Plan a trip to ${name}">↗</button>
        </div>
      </div>
    </article>`;
}

function renderDestinations() {
  $("#featuredDestinations").innerHTML =
    destinations.slice(0, 3).map(destinationCard).join("");

  filterDestinations();
}

function filterDestinations() {
  const search = ($("#destinationSearch")?.value || "").trim().toLowerCase();
  const interest = $("#interestFilter")?.value || "all";

  const filtered = destinations.filter(destination => {
    const text = `${destination.name} ${destination.country} ${destination.description} ${destination.interest}`.toLowerCase();
    return text.includes(search) &&
      (interest === "all" || destination.interest === interest);
  });

  $("#allDestinations").innerHTML =
    filtered.map(destinationCard).join("");

  $("#resultsCount").textContent =
    `${filtered.length} ${filtered.length === 1 ? "destination" : "destinations"} to explore`;

  $("#noDestinations").classList.toggle("hidden", filtered.length !== 0);
}
/* ---------------- NAVIGATION ---------------- */
function navigateTo(pageId) {
  const validPages = ["home", "explore", "planner", "trips", "expenses"];

  if (!validPages.includes(pageId)) pageId = "home";

  $$(".page").forEach(page => {
    page.classList.toggle("active", page.id === pageId);
  });

  $$(".nav-links a").forEach(link => {
    const active = link.dataset.page === pageId;
    link.classList.toggle("active", active);
    if (active) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });

  $("#navLinks").classList.remove("open");
  $("#mobileMenu").setAttribute("aria-expanded", "false");
  $("#mobileMenu").textContent = "☰";

  if (pageId === "trips") renderTrips();
  if (pageId === "expenses") renderExpenses();
  if (pageId === "explore") filterDestinations();

  window.scrollTo({ top: 0, behavior: "smooth" });
}

function handleHashChange() {
  navigateTo(location.hash.replace("#", "") || "home");
}

$("#mobileMenu").addEventListener("click", () => {
  const isOpen = $("#navLinks").classList.toggle("open");
  $("#mobileMenu").setAttribute("aria-expanded", String(isOpen));
  $("#mobileMenu").textContent = isOpen ? "×" : "☰";
});

window.addEventListener("hashchange", handleHashChange);
/* ---------------- TRIP PLANNER ---------------- */
let selectedInterests = [];
let currentPreview = null;
let currentTripFilter = "all";

const travelTips = [
  "The best itineraries leave a little room for the unexpected.",
  "Sometimes the most memorable stop is the one you never planned.",
  "Give yourself time to explore beyond the famous landmarks.",
  "A slower day can become the highlight of an entire journey.",
  "Keep a little budget aside for spontaneous discoveries.",
  "Try something local. The smallest experiences can tell the biggest stories."
];

$("#newTip").addEventListener("click", () => {
  const current = $("#travelTip").textContent;
  const alternatives = travelTips.filter(tip => tip !== current);
  $("#travelTip").textContent =
    alternatives[Math.floor(Math.random() * alternatives.length)];
});

$("#interestChips").addEventListener("click", event => {
  const button = event.target.closest("[data-interest]");
  if (!button) return;

  const interest = button.dataset.interest;

  if (selectedInterests.includes(interest)) {
    selectedInterests = selectedInterests.filter(item => item !== interest);
    button.classList.remove("selected");
    button.setAttribute("aria-pressed", "false");
  } else {
    selectedInterests.push(interest);
    button.classList.add("selected");
    button.setAttribute("aria-pressed", "true");
  }
});

function setPlannerDates() {
  const start = $("#tripStart");
  const end = $("#tripEnd");

  start.min = todayISO();
  end.min = start.value || todayISO();

  if (!start.value) start.value = todayISO();

  if (!end.value || end.value < start.value) {
    const defaultEnd = new Date(`${start.value}T12:00:00`);
    defaultEnd.setDate(defaultEnd.getDate() + 2);
    end.value = `${defaultEnd.getFullYear()}-${String(defaultEnd.getMonth() + 1).padStart(2, "0")}-${String(defaultEnd.getDate()).padStart(2, "0")}`;
  }
}

$("#tripStart").addEventListener("change", () => {
  $("#tripEnd").min = $("#tripStart").value;
  if ($("#tripEnd").value < $("#tripStart").value) {
    $("#tripEnd").value = $("#tripStart").value;
  }
});

$("#quickSearchForm").addEventListener("submit", event => {
  event.preventDefault();
  const destination = $("#quickDestination").value.trim();
  if (!destination) return;

  $("#tripDestination").value = destination;
  $("#tripTravelers").value = $("#quickTravelers").value;
  setPlannerDates();
  location.hash = "planner";
});

$$("[data-interest]").forEach(element => {
  if (element.classList.contains("experience-card")) {
    element.addEventListener("click", () => {
      const interest = element.dataset.interest;
      if (!selectedInterests.includes(interest)) {
        selectedInterests.push(interest);
      }
      $$(".interest-chip").forEach(chip => {
        const selected = selectedInterests.includes(chip.dataset.interest);
        chip.classList.toggle("selected", selected);
        chip.setAttribute("aria-pressed", String(selected));
      });
    });
  }
});

document.addEventListener("click", event => {
  const planButton = event.target.closest("[data-plan-destination]");
  if (planButton) {
    $("#tripDestination").value = planButton.dataset.planDestination;
    setPlannerDates();
    location.hash = "planner";
  }
});

function daysBetween(start, end) {
  const startDate = new Date(`${start}T12:00:00`);
  const endDate = new Date(`${end}T12:00:00`);
  return Math.round((endDate - startDate) / 86400000) + 1;
}

function createTripFromForm() {
  const destination = $("#tripDestination").value.trim();
  const start = $("#tripStart").value;
  const end = $("#tripEnd").value;
  const travelers = Number($("#tripTravelers").value);
  const budget = Number($("#tripBudget").value || 0);

  if (!destination || !start || !end) {
    toast("Please fill in your destination and travel dates.", true);
    return null;
  }

  if (start < todayISO()) {
    toast("Please select today or a future start date.", true);
    return null;
  }

  if (end < start) {
    toast("Your return date cannot be before your start date.", true);
    return null;
  }

  const duration = daysBetween(start, end);
  if (duration < 1 || duration > 366) {
    toast("Please choose a trip duration of 366 days or less.", true);
    return null;
  }

  if (!Number.isInteger(travelers) || travelers < 1 || travelers > 6) {
    toast("Please select between 1 and 6 travelers.", true);
    return null;
  }

  if (!Number.isFinite(budget) || budget < 0 || budget > 100000000) {
    toast("Please enter a valid budget.", true);
    return null;
  }

  const title = $("#tripTitle").value.trim();

  return {
    id: uid(),
    title: title || `${destination} getaway`,
    destination,
    startDate: start,
    endDate: end,
    travelers,
    budget,
    interests: [...selectedInterests],
    pace: $("#tripPace").value,
    notes: $("#tripNotes").value.trim(),
    createdAt: new Date().toISOString(),
    itinerary: [],
    source: "manual"
  };
}

$("#tripForm").addEventListener("submit", event => {
  event.preventDefault();

  const trip = createTripFromForm();
  if (!trip) return;

  trips.unshift(trip);

  if (!persistData()) {
    trips = trips.filter(item => item.id !== trip.id);
    return;
  }

  renderTrips();
  renderExpenseTripOptions();
  renderDashboardStats();

  toast("Your trip has been saved in this browser.");
  location.hash = "trips";
});

function buildSampleItinerary(trip) {
  const interest = trip.interests[0] || "Discovery";

  const relaxed = trip.pace === "Relaxed";
  const packed = trip.pace === "Packed";

  const dayTemplates = [
    [
      ["09:00", "Explore the local area", "Start with a relaxed walk and get familiar with your surroundings.", "100"],
      ["12:30", "Discover local food", "Look for a local restaurant and try a regional specialty.", "500"],
      ["16:00", "Visit a local highlight", `Spend time exploring a place connected to ${interest.toLowerCase()}.`, "300"]
    ],
    [
      ["09:00", "Visit a cultural landmark", "Discover the area's history, architecture, or local traditions.", "400"],
      ["13:00", "A leisurely lunch", "Take a break and enjoy the local atmosphere.", "500"],
      ["16:00", "An afternoon adventure", "Explore a neighborhood, garden, market, or scenic spot.", "300"]
    ],
    [
      ["09:00", "A scenic morning", "Start your day with a beautiful view or outdoor experience.", "250"],
      ["12:00", "Find a local favorite", "Enjoy a meal and leave time for spontaneous discoveries.", "500"],
      ["15:00", "Your final discoveries", "Visit a favorite spot again or browse for meaningful souvenirs.", "400"]
    ]
  ];

  const duration = daysBetween(trip.startDate, trip.endDate);
  const result = [];

  for (let day = 0; day < duration; day++) {
    const template = dayTemplates[day % dayTemplates.length];
    const chosen = packed ? template : relaxed ? template.slice(0, 2) : template;

    const date = new Date(`${trip.startDate}T12:00:00`);
    date.setDate(date.getDate() + day);

    result.push({
      day: day + 1,
      date: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`,
      activities: chosen.map(item => ({
        id: uid(),
        time: item[0],
        title: item[1],
        description: item[2],
        estimatedCost: Number(item[3]),
        completed: false
      }))
    });
  }

  return result;
}

function renderItinerary(trip, isPreview = false) {
  const section = $("#itineraryResultSection");
  const result = $("#itineraryResult");

  $("#itineraryResultTitle").textContent =
    `${trip.destination} · ${daysBetween(trip.startDate, trip.endDate)} days`;

  $("#saveItineraryTrip").hidden = !isPreview;
  $("#saveItineraryTrip").textContent = "Save as trip";

  result.innerHTML = (trip.itinerary || []).map(day => `
    <article class="itinerary-day">
      <span class="day-label">DAY ${day.day} · ${escapeHTML(day.date)}</span>
      <h3>${escapeHTML(trip.destination)}</h3>
      ${(day.activities || []).map(activity => `
        <div class="itinerary-activity">
          <span class="activity-time">${escapeHTML(activity.time)}</span>
          <div class="activity-info">
            <strong>${escapeHTML(activity.title)}</strong>
            <p>${escapeHTML(activity.description)}</p>
            <span class="activity-cost">Estimated: ${money(activity.estimatedCost)}</span>
          </div>
        </div>`).join("")}
    </article>`).join("");

  section.hidden = false;
  section.scrollIntoView({ behavior: "smooth", block: "start" });
}

$("#previewItinerary").addEventListener("click", () => {
  const trip = createTripFromForm();
  if (!trip) return;

  trip.itinerary = buildSampleItinerary(trip);
  trip.source = "sample";

  currentPreview = trip;
  renderItinerary(trip, true);

  toast("Sample itinerary ready. It is not AI-generated.");
});

$("#saveItineraryTrip").addEventListener("click", () => {
  if (!currentPreview) return;

  const trip = { ...currentPreview, id: uid(), createdAt: new Date().toISOString() };
  trips.unshift(trip);

  if (!persistData()) {
    trips = trips.filter(item => item.id !== trip.id);
    return;
  }

  currentPreview = null;
  renderTrips();
  renderDashboardStats();
  renderExpenseTripOptions();

  toast("Itinerary saved to My Trips.");
  location.hash = "trips";
});
/* ---------------- TRIP MANAGEMENT ---------------- */
function tripStatus(trip) {
  if (trip.endDate < todayISO()) return "past";
  if (trip.startDate > todayISO()) return "upcoming";
  return "ongoing";
}

function formatDate(dateString) {
  if (!dateString) return "Date not set";
  const date = new Date(`${dateString}T12:00:00`);
  if (Number.isNaN(date.getTime())) return "Date not set";

  return date.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric"
  });
}

function findDestinationImage(name) {
  const normalized = String(name || "").toLowerCase();
  const destination = destinations.find(item =>
    normalized.includes(item.name.toLowerCase()) ||
    item.name.toLowerCase().includes(normalized.split(",")[0].trim())
  );

  return destination?.image ||
    "https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=900&q=80";
}

function renderTrips() {
  const list = $("#tripsList");

  const filtered = trips.filter(trip => {
    if (currentTripFilter === "all") return true;
    if (currentTripFilter === "past") return tripStatus(trip) === "past";
    return tripStatus(trip) !== "past";
  });

  list.innerHTML = filtered.map(trip => {
    const status = tripStatus(trip);
    const duration = daysBetween(trip.startDate, trip.endDate);

    return `
      <article class="trip-card">
        <div class="trip-card-image">
          <img src="${escapeHTML(findDestinationImage(trip.destination))}"
               alt="${escapeHTML(trip.destination)}" loading="lazy">
          <span class="trip-status">${escapeHTML(status)}</span>
        </div>
        <div class="trip-card-body">
          <h3>${escapeHTML(trip.title)}</h3>
          <p>${escapeHTML(trip.destination)}</p>
          <div class="trip-details">
            <span>◷ ${escapeHTML(formatDate(trip.startDate))}</span>
            <span>✳ ${duration} days</span>
            <span>♧ ${Number(trip.travelers) || 1} travelers</span>
          </div>
          <div class="trip-card-bottom">
            <span class="trip-budget">${money(trip.budget)}</span>
            <div class="trip-card-actions">
              <button class="icon-button" data-trip-action="view" data-id="${escapeHTML(trip.id)}" aria-label="View itinerary">View</button>
              <button class="icon-button" data-trip-action="edit" data-id="${escapeHTML(trip.id)}" aria-label="Edit trip">Edit</button>
              <button class="icon-button danger" data-trip-action="delete" data-id="${escapeHTML(trip.id)}" aria-label="Delete trip">×</button>
            </div>
          </div>
        </div>
      </article>`;
  }).join("");

  $("#tripsEmpty").classList.toggle("hidden", trips.length > 0);
  list.classList.toggle("hidden", filtered.length === 0);

  if (trips.length > 0 && filtered.length === 0) {
    list.innerHTML = "";
    $("#tripsEmpty").classList.remove("hidden");
    $("#tripsEmpty").querySelector("h3").textContent = "No trips in this category";
    $("#tripsEmpty").querySelector("p").textContent = "Try a different filter to find your journey.";
  } else {
    $("#tripsEmpty").querySelector("h3").textContent = "Your next story starts here.";
    $("#tripsEmpty").querySelector("p").textContent = "You haven't saved a trip yet. Let's change that.";
  }

  renderDashboardStats();
}

$$("[data-trip-filter]").forEach(button => {
  button.addEventListener("click", () => {
    currentTripFilter = button.dataset.tripFilter;
    $$("[data-trip-filter]").forEach(item =>
      item.classList.toggle("active", item === button)
    );
    renderTrips();
  });
});

$("#tripsList").addEventListener("click", event => {
  const button = event.target.closest("[data-trip-action]");
  if (!button) return;

  const trip = trips.find(item => item.id === button.dataset.id);
  if (!trip) return;

  const action = button.dataset.tripAction;

  if (action === "view") {
    if (!trip.itinerary?.length) {
      toast("This trip has no itinerary yet. You can create a sample preview in the planner.");
      $("#tripDestination").value = trip.destination;
      $("#tripStart").value = trip.startDate;
      $("#tripEnd").value = trip.endDate;
      location.hash = "planner";
      return;
    }

    currentPreview = null;
    renderItinerary(trip, false);
    location.hash = "planner";
  }

  if (action === "edit") {
    const title = prompt("Trip name:", trip.title);
    if (title === null) return;

    const destination = prompt("Destination:", trip.destination);
    if (destination === null) return;

    const budgetInput = prompt("Total budget in INR:", String(trip.budget));
    if (budgetInput === null) return;

    const budget = Number(budgetInput);
    if (!title.trim() || !destination.trim() || !Number.isFinite(budget) || budget < 0 || budget > 100000000) {
      toast("Please enter a valid title, destination, and budget.", true);
      return;
    }

    trip.title = title.trim();
    trip.destination = destination.trim();
    trip.budget = budget;

    persistData();
    renderTrips();
    renderExpenseTripOptions();
    toast("Trip details updated.");
  }

  if (action === "delete") {
    if (!confirm(`Delete "${trip.title}" and its associated expenses? This cannot be undone.`)) return;

    trips = trips.filter(item => item.id !== trip.id);
    expenses = expenses.filter(item => item.tripId !== trip.id);

    persistData();
    renderTrips();
    renderExpenses();
    renderExpenseTripOptions();
    toast("Trip and associated expenses deleted.");
  }
});

function renderDashboardStats() {
  $("#statTotal").textContent = trips.length;
  $("#statUpcoming").textContent =
    trips.filter(trip => tripStatus(trip) === "upcoming").length;

  $("#statBudget").textContent = money(
    trips.reduce((sum, trip) => sum + (Number(trip.budget) || 0), 0)
  );

  $("#statSpent").textContent = money(
    expenses.reduce((sum, expense) => sum + (Number(expense.amount) || 0), 0)
  );
}
/* ---------------- EXPENSE MANAGEMENT ---------------- */
const categoryIcons = {
  Accommodation: "⌂",
  Transport: "↗",
  Food: "♨",
  Activities: "✳",
  Shopping: "◇",
  Other: "•"
};

function renderExpenseTripOptions() {
  const options = trips.map(trip =>
    `<option value="${escapeHTML(trip.id)}">${escapeHTML(trip.title)} — ${escapeHTML(trip.destination)}</option>`
  ).join("");

  $("#expenseTrip").innerHTML =
    `<option value="">General expense (no trip)</option>${options}`;

  $("#expenseTripFilter").innerHTML =
    `<option value="all">All trips</option><option value="none">General expenses</option>${options}`;
}

function openExpenseModal(expense = null) {
  $("#expenseForm").reset();
  $("#expenseId").value = expense?.id || "";
  $("#expenseModalTitle").textContent = expense ? "Edit expense" : "Add an expense";
  $("#expenseName").value = expense?.name || "";
  $("#expenseAmount").value = expense?.amount ?? "";
  $("#expenseCategory").value = expense?.category || "Other";
  $("#expenseTrip").value = expense?.tripId || "";
  $("#expenseDate").value = expense?.date || todayISO();
  $("#expenseNotes").value = expense?.notes || "";

  $("#expenseModal").classList.remove("hidden");
  $("#expenseName").focus();
}

function closeExpenseModal() {
  $("#expenseModal").classList.add("hidden");
}

$("#addExpenseBtn").addEventListener("click", () => openExpenseModal());
$("#closeExpenseModal").addEventListener("click", closeExpenseModal);
$("#cancelExpense").addEventListener("click", closeExpenseModal);

$("#expenseModal").addEventListener("click", event => {
  if (event.target === $("#expenseModal")) closeExpenseModal();
});

document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeExpenseModal();
});

$("#expenseForm").addEventListener("submit", event => {
  event.preventDefault();

  const name = $("#expenseName").value.trim();
  const amount = Number($("#expenseAmount").value);
  const date = $("#expenseDate").value;

  if (!name || !date || !Number.isFinite(amount) || amount <= 0 || amount > 100000000) {
    toast("Please enter a valid name, date, and positive amount.", true);
    return;
  }

  const tripId = $("#expenseTrip").value;
  if (tripId && !trips.some(trip => trip.id === tripId)) {
    toast("That trip no longer exists. Please choose another.", true);
    return;
  }

  const existingId = $("#expenseId").value;
  const expense = {
    id: existingId || uid(),
    name,
    amount,
    category: $("#expenseCategory").value,
    tripId,
    date,
    notes: $("#expenseNotes").value.trim(),
    updatedAt: new Date().toISOString()
  };

  if (existingId) {
    const index = expenses.findIndex(item => item.id === existingId);
    if (index === -1) {
      toast("That expense could not be found.", true);
      return;
    }
    expenses[index] = expense;
  } else {
    expenses.unshift(expense);
  }

  if (!persistData()) return;

  closeExpenseModal();
  renderExpenses();
  renderDashboardStats();
  toast(existingId ? "Expense updated." : "Expense saved.");
});

function renderExpenses() {
  const selectedTrip = $("#expenseTripFilter").value || "all";

  const filtered = expenses
    .filter(expense => {
      if (selectedTrip === "all") return true;
      if (selectedTrip === "none") return !expense.tripId;
      return expense.tripId === selectedTrip;
    })
    .sort((a, b) => String(b.date).localeCompare(String(a.date)));

  $("#expenseList").innerHTML = filtered.map(expense => {
    const trip = trips.find(item => item.id === expense.tripId);
    const icon = categoryIcons[expense.category] || "•";

    return `
      <div class="expense-row">
        <div class="expense-icon">${icon}</div>
        <div class="expense-row-main">
          <strong>${escapeHTML(expense.name)}</strong>
          <small>${escapeHTML(expense.category)} · ${escapeHTML(formatDate(expense.date))}${trip ? ` · ${escapeHTML(trip.title)}` : ""}</small>
        </div>
        <span class="expense-row-amount">${money(expense.amount)}</span>
        <div class="expense-row-actions">
          <button class="icon-button" data-expense-action="edit" data-id="${escapeHTML(expense.id)}" aria-label="Edit expense">✎</button>
          <button class="icon-button danger" data-expense-action="delete" data-id="${escapeHTML(expense.id)}" aria-label="Delete expense">×</button>
        </div>
      </div>`;
  }).join("");

  $("#expensesEmpty").classList.toggle("hidden", filtered.length !== 0);

  const total = filtered.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);
  const overallTotal = expenses.reduce((sum, expense) => sum + Number(expense.amount || 0), 0);

  $("#expenseTotal").textContent = money(overallTotal);

  let relevantBudget = 0;
  if (selectedTrip === "all") {
    relevantBudget = trips.reduce((sum, trip) => sum + Number(trip.budget || 0), 0);
  } else if (selectedTrip !== "none") {
    const trip = trips.find(item => item.id === selectedTrip);
    relevantBudget = Number(trip?.budget || 0);
  }

  const percent = relevantBudget > 0
    ? Math.min(100, total / relevantBudget * 100)
    : 0;

  $("#expenseBar").style.width = `${percent}%`;

  if (relevantBudget > 0) {
    $("#expenseSummary").textContent =
      `${money(total)} recorded against ${money(relevantBudget)} budget (${percent.toFixed(1)}% used).`;
  } else {
    $("#expenseSummary").textContent =
      `${money(total)} recorded. Add a trip budget to compare spending against your plans.`;
  }

  renderCategoryBreakdown(filtered);
  renderDashboardStats();
}

function renderCategoryBreakdown(filteredExpenses) {
  const totals = {};

  filteredExpenses.forEach(expense => {
    const category = expense.category || "Other";
    totals[category] = (totals[category] || 0) + Number(expense.amount || 0);
  });

  const sorted = Object.entries(totals).sort((a, b) => b[1] - a[1]);
  const total = sorted.reduce((sum, item) => sum + item[1], 0);

  $("#categoryBreakdown").innerHTML = sorted.length
    ? sorted.map(([category, amount]) => {
      const percent = total ? amount / total * 100 : 0;
      return `
          <div class="category-line">
            <div class="category-label">
              <span>${escapeHTML(category)}</span>
              <strong>${money(amount)}</strong>
            </div>
            <div class="category-track"><span style="width:${percent}%"></span></div>
          </div>`;
    }).join("")
    : `<p class="muted">Your category breakdown will appear when you add expenses.</p>`;
}

$("#expenseTripFilter").addEventListener("change", renderExpenses);

$("#expenseList").addEventListener("click", event => {
  const button = event.target.closest("[data-expense-action]");
  if (!button) return;

  const expense = expenses.find(item => item.id === button.dataset.id);
  if (!expense) return;

  if (button.dataset.expenseAction === "edit") {
    openExpenseModal(expense);
  }

  if (button.dataset.expenseAction === "delete") {
    if (!confirm(`Delete expense "${expense.name}"?`)) return;

    expenses = expenses.filter(item => item.id !== expense.id);
    persistData();
    renderExpenses();
    toast("Expense deleted.");
  }
});
/* ---------------- LOCAL DATA RESET ---------------- */
$("#clearLocalData").addEventListener("click", () => {
  const accepted = confirm(
    "Delete ALL TripTrove trips and expenses saved in this browser? This cannot be undone."
  );

  if (!accepted) return;

  trips = [];
  expenses = [];

  try {
    localStorage.removeItem(STORAGE_KEYS.trips);
    localStorage.removeItem(STORAGE_KEYS.expenses);
  } catch {}

  renderTrips();
  renderExpenses();
  renderExpenseTripOptions();
  renderDashboardStats();

  toast("Local demo data cleared.");
});
/* ---------------- INITIALIZATION ---------------- */
function initialize() {
  $("#currentYear").textContent = new Date().getFullYear();

  setPlannerDates();
  renderDestinations();
  renderTrips();
  renderExpenseTripOptions();
  renderExpenses();
  renderDashboardStats();

  if (location.hash) {
    handleHashChange();
  } else {
    navigateTo("home");
  }
}

initialize();

(function addCuratedTripTroveFeatures() {
  "use strict";

  const extraDestinations = [
    {
      name: "Paris",
      country: "France",
      description: "Iconic architecture, art, cafés, and romantic streets.",
      interest: "Culture",
      image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "London",
      country: "United Kingdom",
      description: "Historic landmarks, royal parks, museums, and markets.",
      interest: "Culture",
      image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Dubai",
      country: "United Arab Emirates",
      description: "Skyline views, desert adventures, and memorable dining.",
      interest: "Adventure",
      image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Goa",
      country: "India",
      description: "Golden beaches, Portuguese heritage, and coastal cuisine.",
      interest: "Relaxation",
      image: "https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Jaipur",
      country: "India",
      description: "Pink-hued palaces, colourful bazaars, and Rajasthani food.",
      interest: "Culture",
      image: "https://images.unsplash.com/photo-1599661046827-dacff0c0f09a?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Udaipur",
      country: "India",
      description: "Romantic lakes, palace architecture, and rooftop dining.",
      interest: "Relaxation",
      image: "https://images.unsplash.com/photo-1577083552431-6e5fd01aa342?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Manali",
      country: "India",
      description: "Mountain scenery, pine forests, and Himalayan adventures.",
      interest: "Nature",
      image: "https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Singapore",
      country: "Singapore",
      description: "Futuristic gardens, waterfront views, and hawker favourites.",
      interest: "Culture",
      image: "https://images.unsplash.com/photo-1525625293386-3f8f99389edd?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "New York City",
      country: "United States",
      description: "Famous city landmarks, neighbourhoods, and food spots.",
      interest: "Adventure",
      image: "https://images.unsplash.com/photo-1518391846015-55a9cc003b25?auto=format&fit=crop&w=900&q=80"
    },
    {
      name: "Santorini",
      country: "Greece",
      description: "Whitewashed villages, blue domes, and Aegean sunsets.",
      interest: "Relaxation",
      image: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?auto=format&fit=crop&w=900&q=80"
    }
  ];

  extraDestinations.forEach(item => {
    const alreadyExists = destinations.some(destination =>
      destination.name.toLowerCase() === item.name.toLowerCase()
    );

    if (!alreadyExists) destinations.push(item);
  });

  const curatedPlans = {
    "kyoto": [
      [
        ["09:00", "Fushimi Inari Taisha", "Walk through the famous vermilion torii gates. Go earlier to avoid the busiest crowds.", 0],
        ["12:00", "Nishiki Market", "Explore Kyoto's food market and try local snacks such as tamagoyaki and pickles.", 800],
        ["15:00", "Kiyomizu-dera", "Visit the hillside temple and enjoy views over Kyoto.", 500],
        ["18:30", "Gion district", "Walk through the historic streets and look for a traditional Kyoto dinner.", 1800]
      ],
      [
        ["08:30", "Arashiyama Bamboo Grove", "Visit the bamboo paths early in the day.", 0],
        ["10:00", "Tenryu-ji", "Explore the temple gardens near Arashiyama.", 600],
        ["12:30", "Arashiyama Yoshimura", "Consider soba noodles with a riverside view; confirm opening hours before visiting.", 1800],
        ["15:30", "Kinkaku-ji", "See Kyoto's celebrated Golden Pavilion.", 500]
      ],
      [
        ["09:30", "Nijo Castle", "Explore the historic castle grounds and gardens.", 800],
        ["12:30", "Kyoto ramen lunch", "Try a well-reviewed ramen shop near Kyoto Station or central Kyoto.", 1200],
        ["15:00", "Philosopher's Path", "Enjoy a peaceful walk beside the canal.", 0],
        ["18:00", "Pontocho Alley", "Browse restaurants along the narrow dining street and choose a local specialty.", 2200]
      ]
    ],

    "amalfi coast": [
      [
        ["09:00", "Positano", "Explore the colourful village streets and beachside views.", 0],
        ["12:30", "Le Tre Sorelle", "A well-known Positano dining option; check current menu and availability.", 3500],
        ["15:00", "Spiaggia Grande", "Relax on Positano's main beach.", 1200],
        ["18:30", "Positano waterfront", "Enjoy the coastal views during golden hour.", 1000]
      ],
      [
        ["09:00", "Amalfi Cathedral", "Visit the cathedral and historic piazza in Amalfi town.", 800],
        ["11:00", "Paper Museum of Amalfi", "Discover the town's traditional paper-making history.", 700],
        ["13:00", "Pasticceria Pansa", "Try local pastries at this historic Amalfi café.", 1200],
        ["15:30", "Atrani", "Walk through the neighbouring village and its small piazza.", 0]
      ],
      [
        ["09:00", "Ravello", "Explore the hilltop town above the Amalfi coastline.", 0],
        ["10:30", "Villa Rufolo", "Visit the gardens and take in the panoramic views.", 1000],
        ["13:00", "Ravello town centre", "Choose a terrace restaurant for a leisurely Italian lunch.", 3000],
        ["16:00", "Amalfi waterfront", "Return to the coast for a relaxed final stroll.", 0]
      ]
    ],

    "swiss alps": [
      [
        ["08:30", "Lauterbrunnen Valley", "See the valley's dramatic cliffs and waterfalls.", 0],
        ["10:30", "Staubbach Falls", "Walk to the viewpoint for the famous waterfall.", 0],
        ["12:30", "Lauterbrunnen village", "Enjoy a Swiss rösti or cheese dish at a local restaurant.", 3000],
        ["15:00", "Wengen", "Take the train up to this car-free mountain village if services permit.", 2500]
      ],
      [
        ["08:00", "Grindelwald", "Explore the mountain village and its scenic viewpoints.", 0],
        ["10:00", "First mountain area", "Consider the cable car and available mountain activities; check seasonal operations.", 7000],
        ["13:00", "Mountain restaurant", "Have lunch with an alpine view.", 3500],
        ["16:00", "Grindelwald village", "Browse local shops and enjoy a relaxed walk.", 500]
      ],
      [
        ["09:00", "Interlaken", "Explore the town between Lake Thun and Lake Brienz.", 0],
        ["11:00", "Höhematte Park", "Enjoy the open park and mountain views.", 0],
        ["12:30", "Swiss lunch", "Try fondue or rösti at a local restaurant.", 3500],
        ["15:00", "Lake Brienz", "Take a lakeside walk or check boat schedules for a scenic trip.", 2500]
      ]
    ],

    "bali": [
      [
        ["08:00", "Tegallalang Rice Terraces", "See Bali's terraced rice landscapes; respect marked paths and local farming areas.", 500],
        ["11:00", "Sacred Monkey Forest Sanctuary", "Visit Ubud's forest sanctuary and follow wildlife safety rules.", 1000],
        ["13:00", "Warung Biah Biah", "Consider Indonesian small plates in Ubud; check current hours.", 1000],
        ["16:00", "Ubud Palace", "Explore the central palace area and surrounding streets.", 0]
      ],
      [
        ["08:00", "Tirta Empul Temple", "Visit the water temple respectfully and follow local dress guidance.", 700],
        ["11:30", "Kintamani viewpoint", "Enjoy views of Mount Batur from the highlands.", 500],
        ["13:00", "Kintamani lunch", "Choose a local restaurant with a volcano view.", 1500],
        ["16:30", "Ubud Art Market", "Browse crafts and souvenirs.", 500]
      ],
      [
        ["09:00", "Uluwatu Temple", "Visit the clifftop temple and follow the site's visitor guidance.", 500],
        ["12:00", "Jimbaran Beach", "Relax by the beach and explore seafood dining options.", 2000],
        ["16:30", "Kecak Fire Dance", "Check the performance schedule and book tickets if available.", 1500],
        ["18:30", "Jimbaran seafood dinner", "Enjoy a sunset meal by the shore.", 2500]
      ]
    ],

    "marrakech": [
      [
        ["09:00", "Jemaa el-Fnaa", "Explore Marrakech's famous central square in daylight.", 0],
        ["11:00", "Bahia Palace", "See the palace's courtyards and decorative architecture.", 800],
        ["13:00", "Nomad", "A popular rooftop dining option; check menus and reserve if needed.", 2500],
        ["15:30", "Marrakech souks", "Browse traditional markets and artisan shops.", 500]
      ],
      [
        ["09:00", "Jardin Majorelle", "Visit the celebrated garden; advance tickets may be needed.", 1800],
        ["11:00", "Yves Saint Laurent Museum", "Explore fashion exhibits if they interest you; check current opening hours.", 1500],
        ["13:00", "Guéliz district", "Take a break at a café and try Moroccan mint tea.", 1000],
        ["16:00", "Koutoubia Mosque gardens", "Enjoy the surrounding gardens and exterior views.", 0]
      ],
      [
        ["09:00", "Ben Youssef Madrasa", "Discover the historic Islamic school and its intricate details.", 800],
        ["11:30", "Le Jardin", "Consider this garden restaurant for lunch; check availability.", 2200],
        ["14:00", "Mellah", "Explore the historic Jewish quarter and nearby streets.", 0],
        ["17:00", "Jemaa el-Fnaa at sunset", "Return to the square as the evening atmosphere develops.", 1500]
      ]
    ],

    "iceland": [
      [
        ["09:00", "Þingvellir National Park", "Explore the rift valley and historic national park.", 1000],
        ["11:30", "Geysir geothermal area", "Watch Strokkur erupt from the marked viewing areas.", 0],
        ["13:00", "Gullfoss waterfall", "Visit the dramatic waterfall and its viewpoints.", 0],
        ["15:00", "Friðheimar", "Consider the greenhouse restaurant; reservations and opening times should be checked.", 4000]
      ],
      [
        ["09:00", "Seljalandsfoss", "Visit the waterfall and check path conditions before walking behind it.", 1000],
        ["11:00", "Skógafoss", "See one of Iceland's best-known waterfalls.", 0],
        ["13:00", "Vík village", "Stop for lunch and a break on the south coast.", 2500],
        ["15:00", "Reynisfjara Beach", "View the black sand beach from safe areas and stay well back from the waves.", 0]
      ],
      [
        ["09:00", "Reykjavík old harbour", "Walk around the waterfront and harbour area.", 0],
        ["11:00", "Hallgrímskirkja", "Visit the landmark church and check tower access.", 1500],
        ["13:00", "Bæjarins Beztu Pylsur", "Try the well-known Reykjavík hot-dog stand.", 1000],
        ["15:00", "Harpa Concert Hall", "Admire the waterfront architecture and explore public areas.", 0]
      ]
    ],

    "paris": [
      [
        ["09:00", "Eiffel Tower", "Visit the landmark and book summit or second-floor tickets in advance.", 3500],
        ["12:00", "Rue Cler", "Browse this lively food street and choose a bakery or bistro.", 2000],
        ["14:00", "Musée du Louvre", "Focus on a few highlights and reserve timed entry where required.", 3000],
        ["18:00", "Seine riverside", "Walk beside the river or consider a sightseeing cruise.", 2500]
      ],
      [
        ["09:00", "Notre-Dame Cathedral", "Visit the cathedral area and check visitor access details.", 0],
        ["11:00", "Sainte-Chapelle", "See the famous stained-glass windows; book ahead if possible.", 1800],
        ["13:00", "Bouillon Chartier", "A traditional Paris dining option; expect queues at busy times.", 2500],
        ["15:30", "Le Marais", "Explore historic streets, boutiques, and cafés.", 1000]
      ],
      [
        ["09:00", "Montmartre", "Walk through the hilltop neighbourhood.", 0],
        ["10:30", "Sacré-Cœur", "Enjoy the basilica and city views.", 0],
        ["12:30", "Rue des Abbesses", "Choose a neighbourhood bistro for lunch.", 2500],
        ["15:00", "Arc de Triomphe", "Visit the monument and consider the rooftop viewpoint.", 2500]
      ]
    ],

    "london": [
      [
        ["09:00", "Westminster", "See Big Ben, Parliament, and Westminster Abbey from the surrounding area.", 0],
        ["11:30", "Westminster Abbey", "Visit the historic church; book admission ahead.", 3500],
        ["13:30", "The Regency Café", "A classic café option for a traditional British-style meal.", 1800],
        ["15:30", "Buckingham Palace", "See the palace exterior and nearby St James's Park.", 0]
      ],
      [
        ["09:00", "Tower of London", "Explore the fortress and Crown Jewels exhibition; allow several hours.", 5000],
        ["12:30", "Borough Market", "Sample food from the market's many vendors.", 2500],
        ["14:00", "Tower Bridge", "Walk across the bridge and consider the exhibition.", 2000],
        ["16:00", "Tate Modern", "Explore the museum's collection and public spaces.", 0]
      ],
      [
        ["09:00", "British Museum", "Choose a few galleries for a focused visit.", 0],
        ["12:00", "Dishoom Covent Garden", "A popular Indian-inspired restaurant; booking or a queue may be necessary.", 3000],
        ["14:00", "Covent Garden", "Explore the market, shops, and street performances.", 0],
        ["16:30", "Hyde Park", "Take a relaxing walk through the park.", 0]
      ]
    ],

    "dubai": [
      [
        ["09:00", "Burj Khalifa", "Reserve an observation-deck time slot in advance.", 5000],
        ["11:30", "Dubai Mall", "Explore the mall and its aquarium area if desired.", 2500],
        ["13:00", "Al Hallab Dubai Mall", "Consider Lebanese cuisine; check the current branch and menu.", 2500],
        ["17:30", "Dubai Fountain", "Check current show schedules and viewing arrangements.", 0]
      ],
      [
        ["09:00", "Al Fahidi Historical Neighbourhood", "Explore the older lanes and heritage buildings.", 500],
        ["11:00", "Dubai Creek abra crossing", "Take a traditional boat crossing if services are operating.", 10],
        ["12:00", "Dubai Spice Souk", "Browse the spice stalls and nearby markets.", 500],
        ["14:00", "Arabian Tea House", "A known local dining option in the heritage area; confirm hours.", 2500]
      ],
      [
        ["08:30", "Jumeirah Mosque area", "Check tour availability and local visitor guidance.", 500],
        ["11:00", "Jumeirah Beach", "Relax by the sea and enjoy views of the Burj Al Arab.", 0],
        ["15:00", "Dubai Marina", "Walk along the waterfront promenade.", 0],
        ["18:00", "Desert safari", "Book a reputable operator and confirm pickup, inclusions, and safety details.", 9000]
      ]
    ],

    "goa": [
      [
        ["08:30", "Basilica of Bom Jesus", "Visit the historic church in Old Goa with respectful attire.", 0],
        ["10:00", "Se Cathedral", "Explore one of Old Goa's best-known heritage churches.", 0],
        ["12:30", "Ritz Classic, Panaji", "A well-known local seafood dining option; check opening hours.", 1800],
        ["16:30", "Fontainhas", "Walk through the colourful Latin Quarter of Panaji.", 0]
      ],
      [
        ["08:30", "Fort Aguada", "Explore the historic fort and coastal viewpoints.", 100],
        ["11:00", "Candolim Beach", "Enjoy a beach walk and time by the sea.", 500],
        ["13:00", "Fisherman's Wharf", "Consider Goan-inspired seafood; verify the nearest operating branch.", 2500],
        ["17:00", "Sinquerim Beach", "Enjoy the late afternoon by the water.", 0]
      ],
      [
        ["09:00", "Anjuna Flea Market area", "Check whether the market is operating on your travel date.", 500],
        ["11:30", "Vagator Beach", "Explore the coastline and nearby viewpoints.", 0],
        ["13:00", "Gunpowder, Assagao", "A popular restaurant for regional cuisine; book ahead if possible.", 2500],
        ["16:30", "Chapora Fort", "Visit if access and weather conditions allow; wear suitable footwear.", 100]
      ]
    ],

    "jaipur": [
      [
        ["08:30", "Amber Fort", "Explore the palace courtyards and hilltop fort.", 1000],
        ["11:30", "Panna Meena ka Kund", "See the historic stepwell nearby.", 0],
        ["13:00", "Laxmi Mishthan Bhandar", "Try Rajasthani thali or local sweets in the old city.", 1200],
        ["16:00", "Hawa Mahal", "See the iconic façade and explore the surrounding market streets.", 200]
      ],
      [
        ["09:00", "City Palace Jaipur", "Explore royal courtyards, museums, and architecture.", 1000],
        ["11:30", "Jantar Mantar", "Discover the historic astronomical instruments.", 300],
        ["13:00", "Rawat Mishtan Bhandar", "Try Jaipur's well-known pyaaz kachori, subject to current availability.", 500],
        ["15:00", "Johari Bazaar", "Browse jewellery, textiles, and traditional handicrafts.", 1000]
      ],
      [
        ["09:00", "Nahargarh Fort", "Enjoy elevated views over Jaipur.", 500],
        ["11:30", "Jal Mahal viewpoint", "Stop for photographs of the palace on the lake; access is restricted.", 0],
        ["13:00", "Chokhi Dhani", "Consider this cultural dining experience; check timings and ticket inclusions.", 2500],
        ["17:00", "Patrika Gate", "Visit the colourful architectural landmark for photographs.", 0]
      ]
    ],

    "udaipur": [
      [
        ["09:00", "City Palace Udaipur", "Explore the palace complex overlooking Lake Pichola.", 1000],
        ["12:00", "Jheel's Ginger Coffee Bar & Bakery", "A popular lakeside-area stop for a casual meal; verify hours.", 1500],
        ["14:00", "Jagdish Temple", "Visit the historic temple near the City Palace.", 0],
        ["17:00", "Lake Pichola boat ride", "Check boat schedules and sunset availability.", 1000]
      ],
      [
        ["09:00", "Saheliyon-ki-Bari", "Walk through the historic garden and fountains.", 100],
        ["11:00", "Fateh Sagar Lake", "Enjoy the lakeside promenade and views.", 0],
        ["13:00", "Natraj Dining Hall", "Consider a traditional Rajasthani thali.", 800],
        ["16:00", "Sajjangarh Monsoon Palace", "Visit for panoramic views if road and weather conditions permit.", 500]
      ],
      [
        ["09:00", "Bagore Ki Haveli", "Explore the heritage haveli and its exhibits.", 200],
        ["11:30", "Ambrai Ghat", "Enjoy lakeside views and photographs.", 0],
        ["13:00", "Upre by 1559 AD", "Consider a rooftop meal with lake views; reserve and check current hours.", 2500],
        ["16:30", "Gangaur Ghat", "Relax by the water and explore the old-city lanes.", 0]
      ]
    ],

    "manali": [
      [
        ["09:00", "Hadimba Devi Temple", "Visit the cedar-forest temple and surrounding paths.", 0],
        ["11:00", "Old Manali", "Explore cafés, shops, and mountain-village lanes.", 500],
        ["13:00", "Johnson's Café", "A known Manali dining option; confirm current operating hours.", 1800],
        ["16:00", "Manu Temple", "Visit the temple area and walk around Old Manali.", 0]
      ],
      [
        ["08:00", "Solang Valley", "Check the weather and choose suitable outdoor activities.", 1500],
        ["11:30", "Atal Tunnel / Sissu excursion", "Go only with a reliable local driver and confirm road and weather conditions.", 3500],
        ["14:00", "Sissu village", "Enjoy mountain views and a local meal.", 1200],
        ["17:00", "Return to Manali", "Allow extra travel time for mountain roads.", 0]
      ],
      [
        ["09:00", "Vashisht Temple and hot springs", "Visit the village and check access to bathing facilities.", 100],
        ["11:30", "Mall Road Manali", "Browse local shops and cafés.", 500],
        ["13:00", "Local Himachali meal", "Ask for siddu or other regional dishes at a reputable local restaurant.", 1200],
        ["15:30", "Beas River viewpoints", "Enjoy the scenery from safe, permitted areas away from strong currents.", 0]
      ]
    ],

    "singapore": [
      [
        ["09:00", "Gardens by the Bay", "Explore the outdoor gardens and book conservatory access if desired.", 3500],
        ["12:30", "Satay by the Bay", "Try satay and other local dishes at the food centre.", 1200],
        ["15:00", "Marina Bay Sands waterfront", "Walk along the waterfront promenade.", 0],
        ["19:30", "Spectra light show area", "Check the current show schedule before planning the evening.", 0]
      ],
      [
        ["09:00", "Merlion Park", "Visit the waterfront landmark and take skyline photographs.", 0],
        ["11:00", "Chinatown", "Explore heritage streets and temples.", 0],
        ["12:30", "Maxwell Food Centre", "Try Hainanese chicken rice or other local hawker dishes.", 1200],
        ["15:00", "National Gallery Singapore", "Explore the regional art collections.", 2500]
      ],
      [
        ["09:00", "Singapore Botanic Gardens", "Enjoy the landscaped gardens and walking trails.", 0],
        ["11:30", "Orchard Road", "Browse the city's major shopping district.", 1000],
        ["13:00", "Lau Pa Sat", "Try local hawker food in the historic market hall.", 1500],
        ["16:00", "Sentosa Island", "Choose a beach or attraction and check admission and transport.", 4000]
      ]
    ],

    "new york city": [
      [
        ["09:00", "Central Park", "Walk through the park and choose a manageable route.", 0],
        ["11:30", "The Metropolitan Museum of Art", "Explore selected galleries and check admission details.", 4500],
        ["14:30", "Levain Bakery", "Try a well-known New York cookie; check the nearest branch.", 1000],
        ["17:00", "Top of the Rock", "Book a timed skyline-viewing slot if desired.", 5000]
      ],
      [
        ["09:00", "Statue of Liberty", "Book official ferry tickets in advance and allow time for security.", 3500],
        ["13:00", "Katz's Delicatessen", "A famous deli option for a classic New York sandwich.", 2500],
        ["15:00", "Brooklyn Bridge", "Walk across the bridge and enjoy the skyline views.", 0],
        ["17:00", "DUMBO", "Explore the waterfront and the well-known Manhattan Bridge viewpoint.", 0]
      ],
      [
        ["09:00", "The High Line", "Walk the elevated park and see the surrounding architecture.", 0],
        ["11:30", "Chelsea Market", "Choose from its many food stalls and shops.", 2000],
        ["14:00", "Times Square", "Experience the busy city centre and nearby shops.", 0],
        ["17:00", "Joe's Pizza", "Consider a classic New York pizza slice; confirm the closest branch.", 1000]
      ]
    ],

    "santorini": [
      [
        ["09:00", "Oia village", "Explore the whitewashed lanes early in the day.", 0],
        ["11:30", "Amoudi Bay", "Walk down carefully to the harbour and explore the waterfront.", 0],
        ["13:00", "Dimitris Ammoudi Taverna", "A known seafood option by the bay; check opening and booking details.", 3500],
        ["18:30", "Oia sunset viewpoint", "Arrive early for a popular sunset location.", 0]
      ],
      [
        ["09:00", "Akrotiri Archaeological Site", "Explore the preserved Bronze Age settlement.", 1500],
        ["11:30", "Red Beach viewpoint", "Check access and conditions; avoid unstable cliff areas.", 0],
        ["13:00", "Santo Wines", "Consider a winery visit with caldera views; book tastings in advance.", 4500],
        ["16:00", "Fira town", "Browse the shops and caldera-side walking paths.", 0]
      ],
      [
        ["09:00", "Fira to Firostefani walk", "Enjoy the caldera views along the walking route.", 0],
        ["11:30", "Museum of Prehistoric Thera", "Explore archaeological finds and local history.", 800],
        ["13:00", "Lucky's Souvlakis", "A casual option for Greek pita and souvlaki; check current hours.", 1200],
        ["16:00", "Kamari Beach", "Relax by the beach and choose a café along the promenade.", 1500]
      ]
    ]
  };

  function normalizeDestination(value) {
    return String(value || "")
      .toLowerCase()
      .split(",")[0]
      .trim();
  }

  function getCuratedPlan(destination) {
    const key = normalizeDestination(destination);
    return curatedPlans[key] || null;
  }

  function mapsLink(place, destination) {
    return "https://www.google.com/maps/search/?api=1&query=" +
      encodeURIComponent(place + ", " + destination);
  }

  window.buildSampleItinerary = function (trip) {
    const plan = getCuratedPlan(trip.destination);

    if (!plan) {
      return buildOriginalFallback(trip);
    }

    const duration = Math.max(
      1,
      Math.min(30, daysBetween(trip.startDate, trip.endDate))
    );

    const relaxed = trip.pace === "Relaxed";
    const result = [];

    for (let day = 0; day < duration; day++) {
      const activitiesForDay = plan[day % plan.length];
      const chosenActivities = relaxed
        ? activitiesForDay.slice(0, 2)
        : activitiesForDay;

      const date = new Date(`${trip.startDate}T12:00:00`);
      date.setDate(date.getDate() + day);

      result.push({
        day: day + 1,
        date: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`,
        activities: chosenActivities.map(item => ({
          id: uid(),
          time: item[0],
          title: item[1],
          description: item[2],
          estimatedCost: item[3],
          completed: false,
          mapsUrl: mapsLink(item[1], trip.destination)
        }))
      });
    }

    return result;
  };

  function buildOriginalFallback(trip) {
    const interest = trip.interests?.[0] || "Discovery";
    const duration = Math.max(
      1,
      Math.min(30, daysBetween(trip.startDate, trip.endDate))
    );

    const templates = [
      [
        ["09:00", "Explore the local area", "Start with a relaxed walk and get familiar with your surroundings.", 100],
        ["12:30", "Discover local food", "Find a local restaurant and try a regional specialty.", 500],
        ["16:00", "Visit a local highlight", `Spend time exploring a place connected to ${interest.toLowerCase()}.`, 300]
      ],
      [
        ["09:00", "Visit a cultural landmark", "Discover local history, architecture, or traditions.", 400],
        ["13:00", "Enjoy a leisurely lunch", "Take a break and enjoy the local atmosphere.", 500],
        ["16:00", "Explore a neighbourhood", "Visit a garden, market, or scenic spot.", 300]
      ],
      [
        ["09:00", "A scenic morning", "Start with a beautiful view or outdoor experience.", 250],
        ["12:00", "Find a local favourite", "Enjoy a meal and leave time for spontaneous discoveries.", 500],
        ["15:00", "Final discoveries", "Browse for meaningful souvenirs or revisit a favourite spot.", 400]
      ]
    ];

    const result = [];

    for (let day = 0; day < duration; day++) {
      const date = new Date(`${trip.startDate}T12:00:00`);
      date.setDate(date.getDate() + day);

      const selected = templates[day % templates.length];

      result.push({
        day: day + 1,
        date: `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`,
        activities: selected.map(item => ({
          id: uid(),
          time: item[0],
          title: item[1],
          description: item[2],
          estimatedCost: item[3],
          completed: false,
          mapsUrl: mapsLink(item[1], trip.destination)
        }))
      });
    }

    return result;
  }

  window.renderItinerary = function (trip, isPreview = false) {
    const section = document.querySelector("#itineraryResultSection");
    const result = document.querySelector("#itineraryResult");

    document.querySelector("#itineraryResultTitle").textContent =
      `${trip.destination} · ${daysBetween(trip.startDate, trip.endDate)} days`;

    document.querySelector("#saveItineraryTrip").hidden = !isPreview;
    document.querySelector("#saveItineraryTrip").textContent = "Save as trip";

    result.innerHTML = (trip.itinerary || []).map(day => `
      <article class="itinerary-day">
        <span class="day-label">DAY ${day.day} · ${escapeHTML(day.date)}</span>
        <h3>${escapeHTML(trip.destination)}</h3>
        ${(day.activities || []).map(activity => `
          <div class="itinerary-activity">
            <span class="activity-time">${escapeHTML(activity.time)}</span>
            <div class="activity-info">
              <strong>${escapeHTML(activity.title)}</strong>
              <p>${escapeHTML(activity.description)}</p>
              <span class="activity-cost">
                Estimated: ${money(activity.estimatedCost)}
              </span>
              <p>
                <a href="${escapeHTML(activity.mapsUrl || mapsLink(activity.title, trip.destination))}"
                   target="_blank"
                   rel="noopener noreferrer"
                   style="color:inherit;text-decoration:underline;font-weight:600;">
                  Open in Google Maps ↗
                </a>
              </p>
            </div>
          </div>
        `).join("")}
      </article>
    `).join("");

    section.hidden = false;
    section.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  if (typeof renderDestinations === "function") {
    renderDestinations();
  }

  console.info(
    "TripTrove curated destination extension loaded:",
    destinations.length,
    "destinations"
  );
})();

buildSampleItinerary = window.buildSampleItinerary;
renderItinerary = window.renderItinerary;
